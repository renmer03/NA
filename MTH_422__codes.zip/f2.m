function fun=f2(x)
     fun=sin(pi*x)+sin(3*pi*x);
     %fun=sin(pi*x);
